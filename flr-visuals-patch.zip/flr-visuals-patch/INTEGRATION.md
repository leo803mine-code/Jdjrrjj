# FLR Visuals — патч (крылья с перьями + автототем)

Новые файлы (положить в `src/main/java/dev/flr/visuals/`):
- `WingModel.java`    — 5 типов перьевых крыльев, чистая геометрия (проверена, превью: wings_preview.png)
- `WingRenderer.java` — рисует крылья, сглаживание, наклон при приседе
- `AutoTotem.java`    — автосвап тотема при падении

## 1. CosmeticsLayer.java — заменить блок крыльев
В `render(...)` весь блок `if (Config.wings) { ... wing(...) ... }` заменить на:

```java
if (Config.wings) {
    int style = Mth.clamp(Config.wingStyle, 0, WingModel.TYPES - 1);
    int accent = style == 0 ? blend(-1, color, 0.25f) : WING_PALETTE[style];   // как было
    WingRenderer.render(poseStack, buffer, player, style, wingScale, accent, lod, limbSwingAmount);
}
```
где `wingScale = (float)(Config.scale * Config.wingSize)`, `lod` = `Config.autoPerf && !isSelf`,
`color` = `Config.color() | 0xFF000000`. Вызывать ПОСЛЕ cape() и halo(). Методы `wing()` и `lerp3()` можно удалить.

В `tri(...)` писать 4 вершины вместо 6 (RenderType.lightning рисует QUADS; сейчас каждый треугольник
уходит как a,b,c,c,b,a — лишние дубли геометрии):
```java
vc.addVertex(m, a[0], a[1], a[2]).setColor(ca);
vc.addVertex(m, b[0], b[1], b[2]).setColor(cb);
vc.addVertex(m, c[0], c[1], c[2]).setColor(cc);
vc.addVertex(m, c[0], c[1], c[2]).setColor(cc);
```

## 2. Config.java
```java
public static boolean autoTotem = true;
public static double  autoTotemFall = 5.0;   // блоков падения; раньше сработает, если удар смертелен
```
(и в `reset()` те же значения). Сохранение в flrvisuals.properties идёт через рефлексию — сработает само.

## 3. FlrVisuals.java (конструктор)
```java
NeoForge.EVENT_BUS.addListener(AutoTotem::tick);
```

## 4. CosmeticsScreen
Добавить переключатель "Auto totem" (`Config.autoTotem`) рядом с Aura/Trail — по аналогии с существующими.
