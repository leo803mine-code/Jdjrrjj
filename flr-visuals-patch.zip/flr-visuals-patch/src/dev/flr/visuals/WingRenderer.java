package dev.flr.visuals;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.util.Mth;
import org.joml.Matrix4f;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/**
 * Рисует перьевые крылья (WingModel) на игроке.
 * Хранит сглаженное состояние на каждого игрока, поэтому нет рывков при прыжке/приседе/приземлении.
 */
public final class WingRenderer {

    private static final Map<UUID, WingModel.State> STATES = new HashMap<>();
    private static long lastCleanup;

    private WingRenderer() {}

    /**
     * Вызывать из CosmeticsLayer.render ПОСЛЕ cape() и halo() (они пишут в RenderType.lightning(),
     * а для не-аддитивных крыльев берётся другой RenderType).
     *
     * @param stack            PoseStack слоя
     * @param limbSwingAmount  параметр render(...) №6 (скорость ходьбы 0..1)
     */
    public static void render(PoseStack stack, MultiBufferSource buffers, AbstractClientPlayer p,
                              int style, float size, int accent, boolean lod, float limbSwingAmount) {
        if (p.isSleeping()) return;

        long now = System.nanoTime();
        WingModel.State st = STATES.get(p.getUUID());
        if (st == null) {
            st = new WingModel.State();
            st.lastNanos = now;
            STATES.put(p.getUUID(), st);
        }
        float dt = Mth.clamp((now - st.lastNanos) / 1.0e9f, 0f, 0.1f);
        st.lastNanos = now;
        st.lastSeenMs = System.currentTimeMillis();
        cleanup(st.lastSeenMs);

        // ---- цели анимации ----
        boolean crouch = p.isCrouching();
        boolean glide = p.isFallFlying();
        boolean air = !p.onGround() && !p.isInWater();
        boolean falling = air && (p.getY() - p.yo) < -0.12;
        float moving = Mth.clamp(limbSwingAmount, 0f, 1f);

        float tSpread = glide ? 0.15f : crouch ? 0.45f : air ? 1.0f : 0.55f + 0.25f * moving;
        float tAmp = 0.07f + 0.14f * moving + (air ? 0.22f : 0f) + (falling ? 0.10f : 0f);
        float tSpeed = (1.4f + 5.0f * moving + (air ? 3.5f : 0f) - (falling ? 1.5f : 0f)) * (float) Config.speed;
        st.update(dt, tSpread, tAmp, tSpeed, crouch ? 1f : 0f);

        // ---- привязка к телу: при приседе туловище наклоняется на 0.5 рад, крылья едут вместе с ним ----
        Matrix4f m = new Matrix4f(stack.last().pose());
        if (st.crouch > 0.001f) {
            m.translate(0f, 0.2f * st.crouch, 0f);   // body.y = 3.2px
            m.rotateX(0.5f * st.crouch);             // body.xRot = 0.5
        }

        // lightning = аддитивный (Energy), debugQuads = обычный альфа-блендинг (тёмные крылья видны)
        VertexConsumer vc = buffers.getBuffer(WingModel.additive(style) ? RenderType.lightning() : RenderType.debugQuads());
        final WingModel.Sink sink = (xyz, argb) -> {
            for (int i = 0; i < 4; i++) {
                vc.addVertex(m, xyz[i * 3], xyz[i * 3 + 1], xyz[i * 3 + 2]).setColor(argb[i]);
            }
        };
        WingModel.build(style, -1, size, st, accent, lod, sink);
        WingModel.build(style, 1, size, st, accent, lod, sink);
    }

    private static void cleanup(long nowMs) {
        if (nowMs - lastCleanup < 5000) return;
        lastCleanup = nowMs;
        Iterator<Map.Entry<UUID, WingModel.State>> it = STATES.entrySet().iterator();
        while (it.hasNext()) {
            if (nowMs - it.next().getValue().lastSeenMs > 10_000) it.remove();
        }
    }
}
