# FLR Visuals

Клиентский косметический мод для Minecraft 1.21.1 (NeoForge 21.1+): крылья с перьями (5 типов),
нимб, плащ, частицы, туман, автототем при падении.

Типы крыльев: Angel, Demon, Dark, Crystal, Energy (см. `wings_preview.png`).
Подключение патча к исходникам: `INTEGRATION.md`.
